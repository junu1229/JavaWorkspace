package com.junu.store.controller;

import com.junu.store.model.Fruit;

/*
 * 
 * 1. 키보드로 입력받아 설정이 되도록 해주세요!
 * 2. 김씨네 과일집에 어떤과일이 몇개가 있는지 보여주는거까지 해주세요!
 * 
 */

public class FruitController {
	private int fruitCount = 0;
	
	private Fruit[] kimsFruit = new Fruit[3]; // 김씨네 가게의 과일 개수는 3가지 입니다!
	
	public Fruit[] showFruit() { // 김씨네 과일에 뭐가 있는지 보여주는거에요 !
		return kimsFruit;
	}
	
	public void addFruit() {
		// ()괄호 안에부분에는 어떤것들을 받아올건지 적어주세요!
		// 이제 받아온 값을 김씨네 가게에 저장해야겠죠?
		// 그리고 kimsFruit[0] kimsFruit[1] kimsFruit[2] 이렇게 저장돼야하니까 이방법 생각해보기
		// fruitCount 활용하기
		
	}

}



