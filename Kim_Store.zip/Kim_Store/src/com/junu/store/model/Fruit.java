package com.junu.store.model;

public class Fruit {
	
	private String name; // 과일의 이름을 입력하는 곳입니다!
	private int num; // 과일의 개수를 입력하는 곳입니다!
	
	/*
	 * 
	 * 1. Generate Constructors from Superclass
	 * 2. Generate Constructor using field
	 * 3. Generate Getter / Setter
	 * 4. Generate toString
	 * 
	 * 이 순서대로 해주시면 됩니다!
	 * 
	 */
	

}
